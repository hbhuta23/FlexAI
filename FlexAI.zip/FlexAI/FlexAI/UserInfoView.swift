//  Enhanced UserInfoView.swift with multi-step onboarding for AI personalization
import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth

struct UserInfoView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var currentStep = 0
    @State private var name = ""
    @State private var age = ""
    @State private var height = ""
    @State private var weight = ""
    @State private var gender = "Male"
    @State private var workoutPreferences: [String] = []
    @State private var subPreferences: [String: [String]] = [:]
    @State private var university = "USF"
    @State private var gradeLevel = "Freshman"
    @State private var dormName = "Juniper Hall"
    @State private var dietaryRestrictions = "None"
    @State private var isLoading = false
    @State private var showError = false

    let genders = ["Male", "Female", "Non-binary"]
    let workoutOptions = ["Weightlifting", "Cardio", "Yoga", "Pilates", "HIIT", "Zumba"]
    let subOptions: [String: [String]] = [
        "Weightlifting": ["Chest", "Back", "Arms", "Legs", "Core", "Shoulders", "Bicep", "Tricep", "Quads", "Glutes"],
        "Cardio": ["Running", "Treadmill", "Cycling", "Stair Master"]
    ]

    let universities = ["USF", "UF", "FSU", "UCF"]
    let gradeLevels = ["Freshman", "Sophomore", "Junior", "Senior", "Graduate"]
    let dorms = ["Juniper Hall", "Maple Hall", "Poplar Hall", "Beta Hall", "Castor Hall", "Greek Village", "The Village"]
    let dietaryOptions = ["Vegetarian", "Vegan", "Halal", "Kosher", "Gluten-Free", "None"]

    var body: some View {
        ZStack {
            VStack {
                ProgressView(value: Double(currentStep + 1), total: 4)
                    .padding()
                currentStepView
                navigationControls
            }
            .padding()
            .disabled(isLoading)
            .blur(radius: isLoading ? 2 : 0)

            if isLoading {
                ProgressView().scaleEffect(1.5)
            }
        }
    }

    @ViewBuilder
    private var currentStepView: some View {
        switch currentStep {
        case 0: personalInfoStep
        case 1: preferencesStep
        case 2: subPreferenceStep
        default: finalProfileStep
        }
    }

    private var personalInfoStep: some View {
        VStack(spacing: 20) {
            Text("Tell Us About Yourself").font(.title2).bold()
            Group {
                TextField("Full Name", text: $name)
                TextField("Age", text: $age).keyboardType(.numberPad)
                TextField("Height (cm)", text: $height).keyboardType(.numberPad)
                TextField("Weight (pounds)", text: $weight).keyboardType(.numberPad)
            }.textFieldStyle(.roundedBorder)
            Picker("Gender", selection: $gender) {
                ForEach(genders, id:\.self) { Text($0) }
            }.pickerStyle(SegmentedPickerStyle())
        }
    }

    private var preferencesStep: some View {
        VStack {
            Text("Select Your Workout Preferences").font(.title2).bold()
            ScrollView {
                FlowLayout(alignment: .leading, spacing: 10) {
                    ForEach(workoutOptions, id:\.self) { option in
                        PreferenceToggle(option: option, isSelected: workoutPreferences.contains(option)) {
                            togglePreference(option)
                        }
                    }
                }
            }
        }
    }
    private func togglePreference(_ option: String) {
          if workoutPreferences.contains(option) {
              workoutPreferences.removeAll { $0 == option }
          } else {
              workoutPreferences.append(option)
          }
      }
      
      private func toggleSubPreference(_ category: String, _ option: String) {
          if subPreferences[category, default: []].contains(option) {
              subPreferences[category]?.removeAll { $0 == option }
          } else {
              subPreferences[category, default: []].append(option)
          }
      }
      
      private func handlePrimaryButtonAction() {
          withAnimation {
              if currentStep < 3 {
                  currentStep += 1
              } else {
                  saveUserData()
              }
          }
      }
    
    private var subPreferenceStep: some View {
        VStack {
            Text("Customize Your Preferences").font(.title2).bold()
            ScrollView {
                ForEach(workoutPreferences, id:\.self) { pref in
                    if let options = subOptions[pref] {
                        VStack(alignment: .leading) {
                            Text(pref).font(.headline)
                            FlowLayout(alignment: .leading, spacing: 10) {
                                ForEach(options, id:\.self) { sub in
                                    PreferenceToggle(option: sub, isSelected: subPreferences[pref, default: []].contains(sub)) {
                                        toggleSubPreference(pref, sub)
                                    }
                                }
                            }
                        }.padding(.bottom)
                    }
                }
            }
        }
    }

    private var finalProfileStep: some View {
        VStack(spacing: 20) {
            Text("Personalize Your Profile").font(.title2).bold()
            Picker("University", selection: $university) {
                ForEach(universities, id: \.self) { Text($0) }
            }.pickerStyle(MenuPickerStyle())

            Picker("Grade Level", selection: $gradeLevel) {
                ForEach(gradeLevels, id: \.self) { Text($0) }
            }.pickerStyle(MenuPickerStyle())

            Picker("Dorm Name", selection: $dormName) {
                ForEach(dorms, id: \.self) { Text($0) }
            }.pickerStyle(MenuPickerStyle())

            Picker("Dietary Restrictions", selection: $dietaryRestrictions) {
                ForEach(dietaryOptions, id: \.self) { Text($0) }
            }.pickerStyle(MenuPickerStyle())
        }
    }

    private var navigationControls: some View {
        HStack {
            if currentStep > 0 {
                Button("Back") { currentStep -= 1 }.buttonStyle(.bordered)
            }
            Spacer()
            Button(action: handlePrimaryButtonAction) {
                Text(currentStep == 3 ? "Finish" : "Next").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            // No .disabled modifier since all steps are always valid
        }.padding(.top)
    }

    private var isCurrentStepValid: Bool {
        // All steps are valid since all fields are optional
        return true
    }

    private var errorMessage: String {
        // No error messages needed since all fields are optional
        return ""
    }

    private func validatePersonalInfo() -> Bool {
        // No validation needed - all personal info fields are optional
        return true
    }

    private func saveUserData() {
        isLoading = true
        
        // All fields are optional, so we don't need validation
        guard let userID = Auth.auth().currentUser?.uid else {
            showError = true
            isLoading = false
            return
        }

        // Convert numeric fields to Int only if they contain valid numbers
        let ageValue = Int(age) ?? 0
        let heightValue = Int(height) ?? 0
        let weightValue = Int(weight) ?? 0

        let userData: [String: Any] = [
            "name": name,
            "age": ageValue,
            "height": heightValue,
            "weight": weightValue,
            "gender": gender,
            "workoutPreferences": workoutPreferences,
            "subPreferences": subPreferences,
            "university": university,
            "gradeLevel": gradeLevel,
            "dormName": dormName,
            "dietaryRestrictions": dietaryRestrictions,
            "timestamp": Timestamp(),
            "completedOnboarding": true
        ]

        Firestore.firestore().collection("users").document(userID).setData(userData) { error in
            DispatchQueue.main.async {
                isLoading = false
                if let error = error {
                    print("Error saving user data: \(error.localizedDescription)")
                    showError = true
                } else {
                    generateWorkoutPlan()
                }
            }
        }
    }
    private func generateWorkoutPlan() {
        guard let ageInt = Int(age),
              let heightInt = Int(height),
              let weightInt = Int(weight) else {
            showError = true
            return
        }

        AIPlanService.shared.generateDetailedPlan(
            name: name,
            age: ageInt,
            height: heightInt,
            weight: weightInt,
            preferences: workoutPreferences
        ) { plan in
            if let plan = plan {
                saveWorkoutPlan(plan: plan)
            } else {
                showError = true
            }
        }
    }

    private func saveWorkoutPlan(plan: WorkoutPlan) {
        guard let userID = Auth.auth().currentUser?.uid else {
            showError = true
            return
        }

        let planData: [String: Any] = [
            "summary": plan.summary,
            "exercises": plan.exercises,
            "nutrition": plan.nutrition,
            "lastUpdated": Timestamp()
        ]

        Firestore.firestore().collection("users").document(userID).updateData([
            "workoutPlan": planData
        ]) { error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error saving workout plan: \(error.localizedDescription)")
                    showError = true
                } else {
                    authVM.shouldShowUserInfo = false
                }
            }
        }
    }
}

struct TagBubbleField: View {
    let title: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundColor(.secondary)
            TextField(title, text: $text)
                .padding(10)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
        }
    }
}

struct PreferenceToggle: View {
    let option: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(option)
                .font(.subheadline)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(isSelected ? Color.blue.opacity(0.2) : Color.gray.opacity(0.15))
                .foregroundColor(isSelected ? .blue : .primary)
                .cornerRadius(20)
        }
    }
}

struct FlowLayout<Content: View>: View {
    let alignment: HorizontalAlignment
    let spacing: CGFloat
    let content: Content

    init(alignment: HorizontalAlignment = .leading, spacing: CGFloat = 8, @ViewBuilder content: () -> Content) {
        self.alignment = alignment
        self.spacing = spacing
        self.content = content()
    }

    var body: some View {
        VStack(alignment: alignment, spacing: spacing) {
            content
        }
    }
}
