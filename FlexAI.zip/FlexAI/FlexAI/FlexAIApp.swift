import SwiftUI
import Firebase

@main
struct FlexAIApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var authVM = AuthViewModel()

    init() {
        print("✅ Firebase configured successfully")
    }

    var body: some Scene {
        WindowGroup {
            NavigationStack {
                RootView()
                    .environmentObject(authVM)
            }
        }
    }
}

struct RootView: View {
    @EnvironmentObject var authVM: AuthViewModel

    var body: some View {
        Group {
            if authVM.isLoading {
                ProgressView("Loading...")
            } else if !authVM.isLoggedIn {
                LoginView()
            } else if authVM.shouldShowUserInfo {
                UserInfoView()
            } else {
                HomeDashboardView()
            }
        }
        .onAppear {
            authVM.checkAuthState()
        }
    }
}
