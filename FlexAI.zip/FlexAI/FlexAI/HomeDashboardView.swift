//
//  HomeDashboardView.swift
//  FlexAI
//
//  Created by Aastha Jakasania on 4/5/25.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct HomeDashboardView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var selectedTab: Tab = .dashboard

    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardContentView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .tag(Tab.dashboard)

            AIRecommendationsView()
                .tabItem {
                    Label("AI", systemImage: "sparkles")
                }
                .tag(Tab.ai)

            SocialFeedView()
                .tabItem {
                    Label("Social", systemImage: "person.3.fill")
                }
                .tag(Tab.social)

            UserProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
                .tag(Tab.profile)
        }
    }

    enum Tab {
        case dashboard, ai, social, profile
    }
}

// MARK: - Dashboard with AI & Firestore Integration

struct DashboardContentView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var workoutPlan: WorkoutPlan?
    @State private var challenges: [CampusChallenge] = []
    @State private var isLoading = false
    @State private var showError = false
    @State private var points = 500
    @State private var name = ""
    @State private var age = ""
    @State private var height = 170
    @State private var weight = 70
    @State private var workoutPreferences: [String] = []
    @State private var dormName = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Text("Welcome to FlexAI")
                    .font(.largeTitle)
                    .bold()
                Text("Track your workouts, join dorm challenges, earn rewards!")
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                workoutPlanSection
                challengesSection
                pointsSection
            }
            .padding()
        }
        .onAppear {
            isLoading = true
            loadUserData()
        }
        .alert("Error", isPresented: $showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Failed to load data. Please try again.")
        }
    }

    private var workoutPlanSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Your Workout Plan").font(.title3).bold()
                Spacer()
                Button(action: refreshWorkoutPlan) {
                    Image(systemName: "arrow.clockwise")
                }
            }

            if isLoading {
                ProgressView().frame(height: 100)
            } else if let plan = workoutPlan {
                VStack(alignment: .leading, spacing: 8) {
                    Text(plan.summary).font(.body)
                    if !plan.exercises.isEmpty {
                        Divider()
                        Text("Exercises").font(.headline)
                        ForEach(plan.exercises, id: \.self) { Text("• \($0)") }
                    }
                    if !plan.nutrition.isEmpty {
                        Divider()
                        Text("Nutrition").font(.headline)
                        ForEach(plan.nutrition, id: \.self) { Text("• \($0)") }
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(radius: 2)
            }
        }
    }

    private var challengesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Current Challenges").font(.title3).bold()
            ForEach(challenges.filter { $0.dorm == dormName || $0.dorm == "All" }) { challenge in
                VStack(alignment: .leading, spacing: 4) {
                    Text(challenge.title).font(.headline)
                    Text(challenge.description).font(.subheadline)
                    Text("Reward: \(challenge.reward)").font(.subheadline).foregroundColor(.green)
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(12)
            }
        }
    }

    private var pointsSection: some View {
        VStack(spacing: 8) {
            Text("Your Points").font(.title3).bold()
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("\(points)").font(.system(size: 48, weight: .bold)).foregroundColor(.blue)
            Text("Next Reward: USF Hoodie (1000 pts)")
                .font(.subheadline).foregroundColor(.secondary)
        }
        .padding()
        .background(Color.green.opacity(0.1))
        .cornerRadius(12)
    }

    private func loadUserData() {
        isLoading = true
        guard let userID = Auth.auth().currentUser?.uid else { showError = true; return }
        Firestore.firestore().collection("users").document(userID).getDocument { snapshot, error in
            DispatchQueue.main.async {
                isLoading = false
                if let error = error {
                    print("Error fetching profile: \(error.localizedDescription)")
                    showError = true
                    return
                }
                guard let data = snapshot?.data() else { showError = true; return }
                self.name = data["name"] as? String ?? ""
                self.age = String(data["age"] as? Int ?? 0)
                self.height = data["height"] as? Int ?? 170
                self.weight = data["weight"] as? Int ?? 70
                self.workoutPreferences = data["workoutPreferences"] as? [String] ?? []
                self.dormName = data["dormName"] as? String ?? ""
                self.points = Int.random(in: 400...900)

                if let planData = data["workoutPlan"] as? [String: Any] {
                    workoutPlan = WorkoutPlan(
                        summary: planData["summary"] as? String ?? "",
                        exercises: planData["exercises"] as? [String] ?? [],
                        nutrition: planData["nutrition"] as? [String] ?? []
                    )
                } else {
                    generateWorkoutPlan()
                }

                challenges = [
                    CampusChallenge(title: "Dorm Step Challenge", description: "10,000 steps/day", reward: "USF Bookstore Discount", dorm: "Juniper Hall"),
                    CampusChallenge(title: "Weightlifting Leaderboard", description: "Most reps wins!", reward: "Protein Shake", dorm: "Greek Village"),
                    CampusChallenge(title: "Yoga Streak", description: "7 days in a row", reward: "Yoga Mat", dorm: "The Village"),
                    CampusChallenge(title: "All-Campus Squat-Off", description: "Most squats this week!", reward: "$10 Dining Dollars", dorm: "All")
                ]
            }
        }
    }

    public func generateWorkoutPlan() {
        guard let ageInt = Int(age), ageInt > 0 else {
            print("⚠️ Missing or invalid age.")
            showError = true
            return
        }

        print("🧠 Generating AI workout plan...")
        isLoading = true
        AIPlanService.shared.generateDetailedPlan(
            name: name,
            age: ageInt,
            height: height,
            weight: weight,
            preferences: workoutPreferences
        ) { plan in
            DispatchQueue.main.async {
                self.isLoading = false
                if let plan = plan {
                    self.workoutPlan = plan
                    saveWorkoutPlan(plan: plan)
                } else {
                    print("❌ AI did not return a plan.")
                    self.showError = true
                }
            }
        }
    }

    private func refreshWorkoutPlan() {
        generateWorkoutPlan()
    }
    private func fetchUserProfile() {
        guard let userID = Auth.auth().currentUser?.uid else {
            print("❌ No user ID found.")
            showError = true
            return
        }

        Firestore.firestore().collection("users").document(userID).getDocument { snapshot, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("🔥 Error fetching profile: \(error.localizedDescription)")
                    showError = true
                    return
                }

                guard let data = snapshot?.data() else {
                    print("⚠️ No data found in user document.")
                    showError = true
                    return
                }

                print("✅ User data: \(data)")

                // Assign default values with safe casting
                self.name = data["name"] as? String ?? ""
                self.age = "\(data["age"] as? Int ?? 0)"
                self.workoutPreferences = data["workoutPreferences"] as? [String] ?? []

                if let planData = data["workoutPlan"] as? [String: Any] {
                    self.workoutPlan = WorkoutPlan(
                        summary: planData["summary"] as? String ?? "",
                        exercises: planData["exercises"] as? [String] ?? [],
                        nutrition: planData["nutrition"] as? [String] ?? []
                    )
                } else {
                    print("ℹ️ No workoutPlan found — generating new one.")
                    generateWorkoutPlan()
                }

                isLoading = false
            }
        }
    }

    private func saveWorkoutPlan(plan: WorkoutPlan) {
        guard let userID = Auth.auth().currentUser?.uid else { showError = true; return }
        let planData: [String: Any] = [
            "summary": plan.summary,
            "exercises": plan.exercises,
            "nutrition": plan.nutrition,
            "lastUpdated": Timestamp()
        ]
        Firestore.firestore().collection("users").document(userID).updateData(["workoutPlan": planData]) { error in
            if let error = error {
                print("Error saving workout plan: \(error.localizedDescription)")
                showError = true
            }
        }
    }
}

struct AIRecommendationsView: View {
    @State private var suggestions = [
        "🧘 Try a morning yoga flow for flexibility.",
        "🏋️ Add progressive overload to your bench press.",
        "🥗 Include more protein in your lunch.",
        "🚶 Join the campus step challenge today!"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("AI-Powered Suggestions")
                    .font(.title2).bold()

                ForEach(suggestions, id: \.self) { suggestion in
                    HStack(alignment: .top) {
                        Image(systemName: "sparkles")
                            .foregroundColor(.purple)
                        Text(suggestion)
                    }
                    .padding()
                    .background(Color.purple.opacity(0.1))
                    .cornerRadius(10)
                }
            }
            .padding()
        }
    }
}


struct SocialFeedView: View {
    @State private var posts = [
        "Just finished a 5k run! 🏃‍♀️🔥",
        "Hit a new PR on squats! 🏋️",
        "Joined the dorm yoga challenge! 🧘‍♂️"
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("Campus Feed")
                    .font(.title2).bold()

                ForEach(posts.indices, id: \.self) { index in
                    VStack(alignment: .leading, spacing: 8) {
                        Text("User \(index + 1)")
                            .font(.headline)
                        Text(posts[index])
                        HStack {
                            Button(action: {
                                print("Liked post \(index + 1)")
                            }) {
                                Label("Like", systemImage: "hand.thumbsup")
                            }
                            Spacer()
                            Button(action: {
                                print("Comment on post \(index + 1)")
                            }) {
                                Label("Comment", systemImage: "bubble.right")
                            }
                        }
                        .font(.subheadline)
                        .foregroundColor(.blue)
                    }
                    .padding()
                    .background(Color.blue.opacity(0.05))
                    .cornerRadius(10)
                }
            }
            .padding()
        }
    }
}


struct UserProfileView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var name = ""
    @State private var dorm = ""
    @State private var points = 0
    @State private var showError = false

    var body: some View {
        Form {
            Section(header: Text("Personal Info")) {
                TextField("Name", text: $name)
                TextField("Dorm", text: $dorm)
            }

            Section(header: Text("Flex Points")) {
                HStack {
                    Text("Current Points")
                    Spacer()
                    Text("\(points)").bold().foregroundColor(.green)
                }
                Text("You're halfway to a USF hoodie!")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }

            Section {
                Button("Sign Out") {
                    try? Auth.auth().signOut()
                    authVM.logout()
                }
                .foregroundColor(.red)
            }
        }
        .navigationTitle("Profile")
        .onAppear(perform: loadProfile)
        .alert("Error", isPresented: $showError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Failed to load profile.")
        }
    }

    func loadProfile() {
        guard let userID = Auth.auth().currentUser?.uid else { showError = true; return }

        Firestore.firestore().collection("users").document(userID).getDocument { snapshot, error in
            if let error = error {
                print("❌ Profile Load Error: \(error.localizedDescription)")
                showError = true
                return
            }

            if let data = snapshot?.data() {
                self.name = data["name"] as? String ?? ""
                self.dorm = data["dormName"] as? String ?? ""
                self.points = data["points"] as? Int ?? 0
            }
        }
    }
}


struct WorkoutPlan: Codable {
    let summary: String
    let exercises: [String]
    let nutrition: [String]
}

struct CampusChallenge: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let reward: String
    let dorm: String
}

struct CampusGroup: Identifiable {
    let id = UUID()
    let name: String
    let tags: [String]
    let description: String
}

struct HomeDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        HomeDashboardView()
            .environmentObject(AuthViewModel())
    }
}
  
