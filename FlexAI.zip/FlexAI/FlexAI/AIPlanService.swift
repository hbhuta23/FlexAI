import Foundation

struct GPTPlanResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable {
            let content: String
        }
        let message: Message
    }
    let choices: [Choice]
}

class APIKeyLoader {
    static func loadAPIKey() -> String? {
        guard let path = Bundle.main.path(forResource: "Secrets", ofType: "plist"),
              let dict = NSDictionary(contentsOfFile: path),
              let apiKey = dict["OPENAI_API_KEY"] as? String else {
            print("❌ Failed to load OpenAI API key")
            return nil
        }
        return apiKey
    }
}

class AIPlanService {
    static let shared = AIPlanService()
    private init() {}

    func generateDetailedPlan(
        name: String,
        age: Int,
        height: Int,
        weight: Int,
        preferences: [String],
        completion: @escaping (WorkoutPlan?) -> Void
    ) {
        guard let url = URL(string: "https://api.openai.com/v1/chat/completions") else {
            print("❌ Invalid OpenAI URL")
            completion(nil)
            return
        }

        guard let apiKey = APIKeyLoader.loadAPIKey() else {
            print("❌ API key not found.")
            completion(nil)
            return
        }

        let prompt = """
        Create a JSON-formatted personalized weekly workout and nutrition plan for a user named \(name), age \(age), height \(height) cm, weight \(weight) kg. Preferences: \(preferences.joined(separator: ", ")). Return ONLY a JSON object like:
        {
            "summary": "...",
            "exercises": ["..."],
            "nutrition": ["..."]
        }
        """

        let requestBody: [String: Any] = [
            "model": "gpt-4",
            "messages": [
                ["role": "system", "content": "You are a fitness and nutrition expert."],
                ["role": "user", "content": prompt]
            ],
            "temperature": 0.7
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        } catch {
            print("❌ Failed to encode request body:", error)
            completion(nil)
            return
        }

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print("❌ API error:", error.localizedDescription)
                completion(nil)
                return
            }

            guard let data = data else {
                print("❌ No data returned from OpenAI")
                completion(nil)
                return
            }

            do {
                let gptResponse = try JSONDecoder().decode(GPTPlanResponse.self, from: data)
                guard let content = gptResponse.choices.first?.message.content else {
                    print("❌ No content in response")
                    completion(nil)
                    return
                }

                // Extract JSON string from content
                guard let jsonStart = content.range(of: "{") else {
                    print("❌ JSON start not found")
                    completion(nil)
                    return
                }

                let jsonString = String(content[jsonStart.lowerBound...])
                guard let jsonData = jsonString.data(using: .utf8) else {
                    print("❌ Failed to convert JSON string to Data")
                    completion(nil)
                    return
                }

                let plan = try JSONDecoder().decode(WorkoutPlan.self, from: jsonData)
                DispatchQueue.main.async {
                    completion(plan)
                }
            } catch {
                print("❌ Decoding error:", error.localizedDescription)
                completion(nil)
            }
        }.resume()
    }
}
