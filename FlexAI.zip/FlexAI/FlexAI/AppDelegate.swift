//
//  AppDelegate.swift
//  FlexAI
//
//  Created by Aastha Jakasania on 4/5/25.
//


import FirebaseCore
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, 
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        FirebaseApp.configure() // This must be called first
        return true
    }
}
