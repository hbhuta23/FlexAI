import SwiftUI
import FirebaseAuth

struct LoginView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var isSignUp = false
    @State private var isLoading = false
    @State private var showUserInfoView = false
    
    var body: some View {
        ZStack {
            // Main Content
            VStack(spacing: 20) {
                // App Logo/Title
                Text("FlexAI")
                    .font(.largeTitle)
                    .bold()
                    .padding(.bottom, 30)
                
                // Email Field
                VStack(alignment: .leading, spacing: 5) {
                    Text("Email")
                        .font(.subheadline)
                    TextField("Enter your email", text: $email)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
                
                // Password Field
                VStack(alignment: .leading, spacing: 5) {
                    Text("Password")
                        .font(.subheadline)
                    SecureField("Enter your password", text: $password)
                        .textFieldStyle(.roundedBorder)
                }
                
                // Primary Auth Button
                Button(action: handleAuthAction) {
                    HStack {
                        if isLoading && !authVM.isGoogleSignInLoading {
                            ProgressView()
                                .tint(.white)
                        }
                        Text(isSignUp ? "Create Account" : "Login")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(shouldDisablePrimaryButton)
                
                // Divider
                HStack {
                    VStack { Divider() }
                    Text("OR")
                    VStack { Divider() }
                }
                .padding(.vertical)
                
                // Google Sign-In Button
                Button {
                    handleGoogleSignIn()
                } label: {
                    HStack {
                        if authVM.isGoogleSignInLoading {
                            ProgressView()
                                .tint(.blue)
                        } else {
                            Image(systemName: "g.circle.fill")
                        }
                        Text("Continue with Google")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .disabled(authVM.isGoogleSignInLoading)
                
                // Toggle between Login/Signup
                Button(action: { isSignUp.toggle() }) {
                    Text(isSignUp ? "Already have an account? Login" : "Need an account? Sign Up")
                        .foregroundColor(.blue)
                }
                .padding(.top)
                
                // Error Message
                if let error = authVM.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding(.top)
                }
            }
            .padding(.horizontal, 30)
            .disabled(isLoading)
            .fullScreenCover(isPresented: $showUserInfoView) {
                UserInfoView()
            }
            
            // Loading Overlay
            if isLoading {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                ProgressView()
                    .scaleEffect(1.5)
            }
        }
    }
    
    private var shouldDisablePrimaryButton: Bool {
        isLoading || email.isEmpty || password.isEmpty
    }
    
    private func handleAuthAction() {
        isLoading = true
        authVM.errorMessage = nil
        
        let completion: (Bool) -> Void = { success in
            isLoading = false
            if success && authVM.shouldShowUserInfo {
                showUserInfoView = true
            }
        }
        
        if isSignUp {
            authVM.signUp(email: email, password: password, completion: completion)
        } else {
            authVM.login(email: email, password: password, completion: completion)
        }
    }
    
    private func handleGoogleSignIn() {
        isLoading = true
        authVM.errorMessage = nil
        
        authVM.signInWithGoogle { success in
            isLoading = false
            if success && authVM.shouldShowUserInfo {
                showUserInfoView = true
            }
        }
    }
}

// MARK: - Preview
struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .environmentObject(AuthViewModel())
    }
}
