import SwiftUI
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth
import GoogleSignIn

class AuthViewModel: ObservableObject {
    @Published var isLoggedIn = false
    @Published var isGoogleSignInLoading = false
    @Published var errorMessage: String?
    @Published var shouldShowUserInfo = false
    @Published var isLoading = true

    init() {
        // Initialization is handled through manual call to checkAuthState()
    }

    func checkAuthState(completion: @escaping () -> Void = {}) {
        isLoading = true

        if let user = Auth.auth().currentUser {
            isLoggedIn = true
            checkIfUserInfoNeeded(userID: user.uid) { needsInfo in
                DispatchQueue.main.async {
                    self.shouldShowUserInfo = needsInfo
                    self.isLoading = false
                    completion()
                }
            }
        } else {
            DispatchQueue.main.async {
                self.isLoggedIn = false
                self.shouldShowUserInfo = false
                self.isLoading = false
                completion()
            }
        }
    }

    func signUp(email: String, password: String, completion: @escaping (Bool) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] _, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.errorMessage = error.localizedDescription
                    completion(false)
                } else {
                    self?.isLoggedIn = true
                    self?.shouldShowUserInfo = true // New users go to onboarding
                    completion(true)
                }
            }
        }
    }

    func login(email: String, password: String, completion: @escaping (Bool) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let error = error {
                    self.errorMessage = error.localizedDescription
                    completion(false)
                } else {
                    self.isLoggedIn = true
                    if let uid = Auth.auth().currentUser?.uid {
                        self.checkIfUserInfoNeeded(userID: uid) { needsInfo in
                            DispatchQueue.main.async {
                                self.shouldShowUserInfo = needsInfo
                                completion(true)
                            }
                        }
                    } else {
                        self.shouldShowUserInfo = true
                        completion(true)
                    }
                }
            }
        }
    }

    func signInWithGoogle(completion: @escaping (Bool) -> Void) {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            errorMessage = "Firebase configuration error"
            completion(false)
            return
        }

        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config

        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let rootVC = windowScene.windows.first?.rootViewController else {
            errorMessage = "No root view controller found"
            completion(false)
            return
        }

        isGoogleSignInLoading = true

        GIDSignIn.sharedInstance.signIn(withPresenting: rootVC) { [weak self] result, error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.isGoogleSignInLoading = false

                if let error = error {
                    self.errorMessage = error.localizedDescription
                    completion(false)
                    return
                }

                guard let idToken = result?.user.idToken?.tokenString,
                      let accessToken = result?.user.accessToken.tokenString else {
                    self.errorMessage = "Missing Google auth tokens"
                    completion(false)
                    return
                }

                let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)

                Auth.auth().signIn(with: credential) { [weak self] _, error in
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        if let error = error {
                            self.errorMessage = error.localizedDescription
                            completion(false)
                        } else {
                            self.isLoggedIn = true
                            if let uid = Auth.auth().currentUser?.uid {
                                self.checkIfUserInfoNeeded(userID: uid) { needsInfo in
                                    DispatchQueue.main.async {
                                        self.shouldShowUserInfo = needsInfo
                                        completion(true)
                                    }
                                }
                            } else {
                                self.shouldShowUserInfo = true
                                completion(true)
                            }
                        }
                    }
                }
            }
        }
    }

    private func checkIfUserInfoNeeded(userID: String, completion: @escaping (Bool) -> Void) {
        Firestore.firestore().collection("users").document(userID).getDocument { snapshot, error in
            if let error = error {
                print("❌ Error checking user info: \(error.localizedDescription)")
                completion(true) // Default to needing info on error
                return
            }

            if let data = snapshot?.data() {
                let hasInfo = (data["name"] as? String)?.isEmpty == false && data["age"] != nil
                completion(!hasInfo)
            } else {
                completion(true) // No doc means user info is required
            }
        }
    }

    func markUserInfoCompleted() {
        DispatchQueue.main.async {
            self.shouldShowUserInfo = false
        }
    }

    func logout() {
        do {
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance.signOut()
            DispatchQueue.main.async {
                self.isLoggedIn = false
                self.shouldShowUserInfo = false
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func forceLogout() {
        logout()
    }
}
